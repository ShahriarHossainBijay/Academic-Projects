
package maid_service1;


public class MainClass {

    public static void main(String[] args) {
        
        HomePage f1= new HomePage();
        f1.setVisible(true);
        f1.setTitle("Home");
    }
    
}
