package maid_service.user;

public class userclass {

    public static String Id;
    public static String Name;
    public static String Password;
    public static String Address;
    public static String Company;
    public static int Phonenumber;
}
