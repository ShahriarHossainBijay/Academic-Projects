
package maid_service.admin;


public class AdminClass {
    
     public static String Name;
     public static String id;
     public static String password;
     public static String company;
    
}
