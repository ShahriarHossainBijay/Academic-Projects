
package maid_service.maid;


public class MaidClass {
    
    public static String id;
    public static String Name;
    public static String password;
    public static String worktype;
    public static String location;
    public static String holiday;
    public static int salary;
    public static String workinghours;
    public static int phonenumber;
    
}
