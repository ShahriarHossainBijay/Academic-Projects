-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 22, 2020 at 08:53 AM
-- Server version: 8.0.13-4
-- PHP Version: 7.2.24-0ubuntu0.18.04.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lbxtRrWEUV`
--

-- --------------------------------------------------------

--
-- Table structure for table `clinics`
--

CREATE TABLE `clinics` (
  `id` int(100) NOT NULL,
  `cid` varchar(100) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `phonenumber` varchar(11) NOT NULL,
  `divission` varchar(20) NOT NULL,
  `district` varchar(20) NOT NULL,
  `thana` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `clinics`
--

INSERT INTO `clinics` (`id`, `cid`, `cname`, `phonenumber`, `divission`, `district`, `thana`) VALUES
(17, 'c1', 'aaa', '01840431225', 'Dhaka', 'Ghazipur', 'Kaliakair '),
(18, 'c2', 'bbb', '01521420185', 'Khulna', 'Kushtia', 'Doulatpur '),
(19, 'c3', 'ccc', '01521420185', 'Rajshahi', 'Chapainawabganj', 'Bholahat Upazila'),
(20, 'c4', 'ddd', '01624666666', 'Sylhet', 'Moulvibazar', 'Kamalganj'),
(21, 'c5', 'eee', '01749058829', 'Dhaka', 'Ghazipur', 'Kaliakair ');

-- --------------------------------------------------------

--
-- Table structure for table `diseases`
--

CREATE TABLE `diseases` (
  `id` int(100) NOT NULL,
  `diseases` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `diseases`
--

INSERT INTO `diseases` (`id`, `diseases`) VALUES
(1, 'Autoimmune Diseases.'),
(2, 'Allergies & Asthma.'),
(3, 'Celiac Disease.'),
(4, 'Crohns & Colitis.'),
(5, 'Infectious Diseases.');

-- --------------------------------------------------------

--
-- Table structure for table `district`
--

CREATE TABLE `district` (
  `id` int(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `divission_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `district`
--

INSERT INTO `district` (`id`, `district`, `divission_id`) VALUES
(1, 'Dhaka', 'DHAKA'),
(2, 'Ghazipur', 'DHAKA'),
(3, 'Kishoreganj', 'DHAKA'),
(4, 'Manikganj', 'DHAKA'),
(5, 'Narsingdi', 'DHAKA'),
(6, 'Faridpur', 'DHAKA'),
(7, 'Khulna', 'Khulna'),
(8, 'Kushtia', 'Khulna'),
(9, 'Magura', 'Khulna'),
(10, 'Jhenaidah', 'Khulna'),
(11, 'Bagerhat', 'Khulna'),
(12, 'Satkhira', 'Khulna'),
(13, 'Chittagong', 'Chittagong'),
(14, 'Feni', 'Chittagong'),
(15, 'Rangamati', 'Chittagong'),
(16, 'Noakhali', 'Chittagong'),
(17, 'Bandarban', 'Chittagong'),
(18, 'Khagrachhari', 'Chittagong'),
(19, 'Barguna ', 'Barisal'),
(20, 'Patuakhali', 'Barisal'),
(21, 'Madaripur', 'Barisal'),
(22, 'Bhola', 'Barisal'),
(23, 'Pirojpur', 'Barisal'),
(24, 'Shariatpur', 'Barisal'),
(25, 'Mymensingh ', 'Mymensingh'),
(26, 'Netrokona', 'Mymensingh'),
(27, 'Jamalpur', 'Mymensingh'),
(28, 'Sherpur', 'Mymensingh'),
(29, 'Bogura', 'Rajshahi'),
(30, 'Chapainawabganj', 'Rajshahi'),
(31, 'Joypurhat', 'Rajshahi'),
(32, 'Naogaon', 'Rajshahi'),
(33, 'Dinajpur', 'Rangpur'),
(34, 'Kurigram', 'Rangpur'),
(35, 'Rangpur', 'Rangpur'),
(36, 'Nilphamari', 'Rangpur'),
(37, 'Habiganj', 'Sylhet'),
(38, 'Moulvibazar', 'Sylhet'),
(39, 'Sunamganj', 'Sylhet'),
(40, 'Sylhet', 'Sylhet');

-- --------------------------------------------------------

--
-- Table structure for table `divission`
--

CREATE TABLE `divission` (
  `id` int(100) NOT NULL,
  `divission` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `divission`
--

INSERT INTO `divission` (`id`, `divission`) VALUES
(1, 'Dhaka'),
(2, 'Khulna'),
(3, 'Chittagong'),
(4, 'Barisal'),
(5, 'Mymensingh'),
(6, 'Rajshahi'),
(7, 'Rangpur'),
(8, 'Sylhet');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(100) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(11) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `divission` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `thana` varchar(50) NOT NULL,
  `specialty` varchar(50) NOT NULL,
  `degree` varchar(100) NOT NULL,
  `bmdcregno` varchar(20) NOT NULL,
  `description` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `userid`, `username`, `gender`, `email`, `phonenumber`, `dob`, `divission`, `district`, `thana`, `specialty`, `degree`, `bmdcregno`, `description`) VALUES
(17, 'd1', 'aaa', 'Male', 'a@gmail.com', '01521420185', '2004-06-15', 'Dhaka', 'Ghazipur', 'Kaliakair ', 'Anesthesiology', 'FRCS', '3698521470', 'asdf'),
(18, 'd2', 'bbb', 'Female', 'b@gmail.com', '01521420185', '2014-07-22', 'Khulna', 'Kushtia', 'Doulatpur ', 'Allergy', 'MBBS', '9876543210', 'adsf'),
(19, 'd3', 'ccc', 'Male', 'c@gmail.com', '01624666666', '2013-06-19', 'Rajshahi', 'Chapainawabganj', 'Bholahat Upazila', 'Emergency medicine', 'MBBS', '3698521470', 'vdfd');

-- --------------------------------------------------------

--
-- Table structure for table `doctorsetschedule`
--

CREATE TABLE `doctorsetschedule` (
  `id` int(100) NOT NULL,
  `did` varchar(100) NOT NULL,
  `dname` varchar(100) NOT NULL,
  `cid` varchar(100) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `divission` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `thana` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `doctorsetschedule`
--

INSERT INTO `doctorsetschedule` (`id`, `did`, `dname`, `cid`, `cname`, `time`, `date`, `divission`, `district`, `thana`) VALUES
(35, 'd1', 'aaa', 'c1', 'aaa', '02pm - 05pm', '2020-09-24', 'Dhaka', 'Ghazipur', 'Kaliakair '),
(36, 'd1', 'aaa', 'c2', 'bbb', '08pm - 10pm', '2020-09-30', 'Khulna', 'Kushtia', 'Doulatpur '),
(37, 'd1', 'aaa', 'c3', 'ccc', '08am - 10am', '2020-09-28', 'Rajshahi', 'Chapainawabganj', 'Bholahat Upazila'),
(38, 'd1', 'aaa', 'c4', 'ddd', '08pm - 10pm', '2020-09-29', 'Sylhet', 'Moulvibazar', 'Kamalganj'),
(39, 'd1', 'aaa', 'c5', 'eee', '08am - 10am', '2020-09-27', 'Dhaka', 'Ghazipur', 'Kaliakair '),
(40, 'd2', 'bbb', 'c2', 'bbb', '02pm - 05pm', '2020-09-30', 'Khulna', 'Kushtia', 'Doulatpur '),
(41, 'd2', 'bbb', 'c3', 'ccc', '02pm - 05pm', '2020-09-28', 'Rajshahi', 'Chapainawabganj', 'Bholahat Upazila'),
(42, 'd2', 'bbb', 'c4', 'ddd', '08am - 10am', '2020-09-29', 'Sylhet', 'Moulvibazar', 'Kamalganj'),
(43, 'd2', 'bbb', 'c4', 'ddd', '08am - 10am', '2020-09-29', 'Sylhet', 'Moulvibazar', 'Kamalganj'),
(44, 'd2', 'bbb', 'c5', 'eee', '08am - 10am', '2020-09-27', 'Dhaka', 'Ghazipur', 'Kaliakair '),
(45, 'd2', 'bbb', 'c1', 'aaa', '02pm - 05pm', '2020-09-24', 'Dhaka', 'Ghazipur', 'Kaliakair '),
(46, 'd3', 'ccc', 'c1', 'aaa', '02pm - 05pm', '2020-09-24', 'Dhaka', 'Ghazipur', 'Kaliakair '),
(47, 'd3', 'ccc', 'c2', 'bbb', '02pm - 05pm', '2020-09-30', 'Khulna', 'Kushtia', 'Doulatpur '),
(48, 'd3', 'ccc', 'c3', 'ccc', '08pm - 10pm', '2020-09-28', 'Rajshahi', 'Chapainawabganj', 'Bholahat Upazila'),
(49, 'd3', 'ccc', 'c4', 'ddd', '08am - 10am', '2020-09-29', 'Sylhet', 'Moulvibazar', 'Kamalganj'),
(50, 'd3', 'ccc', 'c5', 'eee', '08pm - 10pm', '2020-09-27', 'Dhaka', 'Ghazipur', 'Kaliakair ');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `id` int(100) NOT NULL,
  `pid` varchar(100) NOT NULL,
  `did` varchar(100) NOT NULL,
  `dname` varchar(100) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `notification` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`id`, `pid`, `did`, `dname`, `cname`, `time`, `date`, `notification`) VALUES
(24, 'p1', 'd1', 'aaa', 'aaa', '02pm - 05pm', '2020-09-24', 'You are appointed'),
(25, 'p1', 'd1', 'aaa', 'bbb', '08pm - 10pm', '2020-09-30', 'You are appointed'),
(26, 'p2', 'd1', 'aaa', 'aaa', '02pm - 05pm', '2020-09-24', 'You are appointed'),
(27, 'p2', 'd1', 'aaa', 'ccc', '08am - 10am', '2020-09-28', 'You are appointed'),
(28, 'p1', 'd1', 'aaa', 'ddd', '08pm - 10pm', '2020-09-29', 'You are appointed'),
(29, 'p1', 'd1', 'aaa', 'ddd', '08pm - 10pm', '2020-09-29', 'You are Rejected');

-- --------------------------------------------------------

--
-- Table structure for table `patientrecords`
--

CREATE TABLE `patientrecords` (
  `id` int(100) NOT NULL,
  `did` varchar(200) NOT NULL,
  `dname` varchar(200) NOT NULL,
  `pid` varchar(200) NOT NULL,
  `pname` varchar(200) NOT NULL,
  `cid` varchar(200) NOT NULL,
  `cname` varchar(200) NOT NULL,
  `time` varchar(200) NOT NULL,
  `date` varchar(200) NOT NULL,
  `symptom` varchar(200) DEFAULT NULL,
  `diseases` varchar(200) NOT NULL,
  `test` varchar(200) NOT NULL,
  `testclinic` varchar(200) DEFAULT NULL,
  `report` varchar(200) NOT NULL,
  `medicines` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `patientrecords`
--

INSERT INTO `patientrecords` (`id`, `did`, `dname`, `pid`, `pname`, `cid`, `cname`, `time`, `date`, `symptom`, `diseases`, `test`, `testclinic`, `report`, `medicines`) VALUES
(7, 'd1', 'aaa', 'p1', 'sadman', 'c1', 'aaa', '02pm - 05pm', '2020-09-24', 'high fever', 'Autoimmune Diseases.', 'ab', 'Ad-Din Hospital', 'good', 'paracitamol\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `patientrequest`
--

CREATE TABLE `patientrequest` (
  `id` int(100) NOT NULL,
  `pid` varchar(100) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `did` varchar(100) NOT NULL,
  `dname` varchar(100) NOT NULL,
  `cid` varchar(100) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `divission` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `thana` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `patientrequest`
--

INSERT INTO `patientrequest` (`id`, `pid`, `pname`, `did`, `dname`, `cid`, `cname`, `time`, `date`, `divission`, `district`, `thana`) VALUES
(41, 'p1', 'sadman', 'd1', 'aaa', 'c3', 'ccc', '08am - 10am', '2020-09-28', 'Rajshahi', 'Chapainawabganj', 'Bholahat Upazila'),
(44, 'p2', 'nabil', 'd1', 'aaa', 'c2', 'bbb', '08pm - 10pm', '2020-09-30', 'Khulna', 'Kushtia', 'Doulatpur '),
(46, 'p2', 'nabil', 'd1', 'aaa', 'c4', 'ddd', '08pm - 10pm', '2020-09-29', 'Sylhet', 'Moulvibazar', 'Kamalganj'),
(48, 'p2', 'nabil', 'd2', 'bbb', 'c5', 'eee', '08am - 10am', '2020-09-27', 'Dhaka', 'Ghazipur', 'Kaliakair '),
(50, 'p3', 'himu', 'd3', 'ccc', 'c1', 'aaa', '02pm - 05pm', '2020-09-24', 'Dhaka', 'Ghazipur', 'Kaliakair '),
(51, 'p3', 'himu', 'd3', 'ccc', 'c2', 'bbb', '02pm - 05pm', '2020-09-30', 'Khulna', 'Kushtia', 'Doulatpur '),
(52, 'p3', 'himu', 'd3', 'ccc', 'c3', 'ccc', '08pm - 10pm', '2020-09-28', 'Rajshahi', 'Chapainawabganj', 'Bholahat Upazila'),
(53, 'p3', 'himu', 'd3', 'ccc', 'c4', 'ddd', '08am - 10am', '2020-09-29', 'Sylhet', 'Moulvibazar', 'Kamalganj'),
(54, 'p3', 'himu', 'd3', 'ccc', 'c5', 'eee', '08pm - 10pm', '2020-09-27', 'Dhaka', 'Ghazipur', 'Kaliakair ');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(100) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `gender` varchar(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phonenumber` varchar(11) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `bloodgroup` varchar(11) NOT NULL,
  `divission` varchar(20) NOT NULL,
  `district` varchar(20) NOT NULL,
  `thana` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `userid`, `username`, `gender`, `email`, `phonenumber`, `dob`, `bloodgroup`, `divission`, `district`, `thana`) VALUES
(14, 'p1', 'sadman', 'Male', 'sadman@gmail.com', '01625153113', '2020-09-11', 'B+', 'Dhaka', 'Ghazipur', 'Kaliakair '),
(16, 'p2', 'nabil', 'Male', 'nabil@gmail.com', '01123456789', '2020-09-19', 'A+', 'Dhaka', 'Kishoreganj', 'Hossainpur '),
(17, 'p3', 'himu', 'Male', 'himu@gmail.com', '01234567891', '2020-08-06', 'O+', 'Rangpur', 'Kurigram', 'Rajarhat Upazila'),
(18, 'p4', 'biju', 'Male', 'biju@gmail.com', '01345678912', '2020-08-05', 'A-', 'Khulna', 'Kushtia', 'Doulatpur '),
(19, 'p5', 'ifty', 'Female', 'ifty@gmail.com', '01123456789', '2019-10-15', 'O+', 'Dhaka', 'Narsingdi', 'Narsingdi Sadar');

-- --------------------------------------------------------

--
-- Table structure for table `patientwaiting`
--

CREATE TABLE `patientwaiting` (
  `id` int(100) NOT NULL,
  `pid` varchar(100) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `did` varchar(100) NOT NULL,
  `dname` varchar(100) NOT NULL,
  `cid` varchar(100) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `divission` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `thana` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `patientwaiting`
--

INSERT INTO `patientwaiting` (`id`, `pid`, `pname`, `did`, `dname`, `cid`, `cname`, `time`, `date`, `divission`, `district`, `thana`) VALUES
(25, 'p1', 'sadman', 'd1', 'aaa', 'c2', 'bbb', '08pm - 10pm', '2020-09-30', 'Khulna', 'Kushtia', 'Doulatpur '),
(26, 'p2', 'nabil', 'd1', 'aaa', 'c1', 'aaa', '02pm - 05pm', '2020-09-24', 'Dhaka', 'Ghazipur', 'Kaliakair '),
(27, 'p2', 'nabil', 'd1', 'aaa', 'c3', 'ccc', '08am - 10am', '2020-09-28', 'Rajshahi', 'Chapainawabganj', 'Bholahat Upazila'),
(28, 'p1', 'sadman', 'd1', 'aaa', 'c4', 'ddd', '08pm - 10pm', '2020-09-29', 'Sylhet', 'Moulvibazar', 'Kamalganj');

-- --------------------------------------------------------

--
-- Table structure for table `slot1`
--

CREATE TABLE `slot1` (
  `id` int(100) NOT NULL,
  `cid` varchar(100) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `slot1` varchar(100) DEFAULT NULL,
  `divission` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `thana` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `slot1`
--

INSERT INTO `slot1` (`id`, `cid`, `cname`, `slot1`, `divission`, `district`, `thana`, `date`) VALUES
(45, 'c1', 'aaa', '08am - 10am', 'Dhaka', 'Ghazipur', 'Kaliakair ', '2020-09-25'),
(46, 'c1', 'aaa', '02pm - 05pm', 'Dhaka', 'Ghazipur', 'Kaliakair ', '2020-09-24'),
(48, 'c1', 'aaa', '08pm - 10pm', 'Dhaka', 'Ghazipur', 'Kaliakair ', '2020-09-25'),
(49, 'c2', 'bbb', '08am - 10am', 'Khulna', 'Kushtia', 'Doulatpur ', '2020-09-29'),
(50, 'c2', 'bbb', '02pm - 05pm', 'Khulna', 'Kushtia', 'Doulatpur ', '2020-09-30'),
(51, 'c2', 'bbb', '08pm - 10pm', 'Khulna', 'Kushtia', 'Doulatpur ', '2020-09-30'),
(52, 'c3', 'ccc', '08am - 10am', 'Rajshahi', 'Chapainawabganj', 'Bholahat Upazila', '2020-09-28'),
(53, 'c3', 'ccc', '02pm - 05pm', 'Rajshahi', 'Chapainawabganj', 'Bholahat Upazila', '2020-09-28'),
(54, 'c3', 'ccc', '08pm - 10pm', 'Rajshahi', 'Chapainawabganj', 'Bholahat Upazila', '2020-09-28'),
(55, 'c4', 'ddd', '08am - 10am', 'Sylhet', 'Moulvibazar', 'Kamalganj', '2020-09-29'),
(56, 'c4', 'ddd', '02pm - 05pm', 'Sylhet', 'Moulvibazar', 'Kamalganj', '2020-09-29'),
(57, 'c4', 'ddd', '08pm - 10pm', 'Sylhet', 'Moulvibazar', 'Kamalganj', '2020-09-29'),
(58, 'c5', 'eee', '08am - 10am', 'Dhaka', 'Ghazipur', 'Kaliakair ', '2020-09-27'),
(59, 'c5', 'eee', '02pm - 05pm', 'Dhaka', 'Ghazipur', 'Kaliakair ', '2020-09-27'),
(60, 'c5', 'eee', '08pm - 10pm', 'Dhaka', 'Ghazipur', 'Kaliakair ', '2020-09-27');

-- --------------------------------------------------------

--
-- Table structure for table `tempdoctorrequests`
--

CREATE TABLE `tempdoctorrequests` (
  `id` int(100) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(11) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `divission` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `thana` varchar(50) NOT NULL,
  `specialty` varchar(50) NOT NULL,
  `degree` varchar(100) NOT NULL,
  `bmdcregno` varchar(20) NOT NULL,
  `description` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tempdoctorrequests`
--

INSERT INTO `tempdoctorrequests` (`id`, `userid`, `username`, `gender`, `email`, `phonenumber`, `dob`, `divission`, `district`, `thana`, `specialty`, `degree`, `bmdcregno`, `description`) VALUES
(20, 'd4', 'ddd', 'Male', 'd@gmail.com', '01749058829', '2015-10-14', 'Dhaka', 'Ghazipur', 'Kaliakair ', 'Neurology', 'FRCS', '3698521470', 'asf'),
(21, 'd5', 'eee', 'Female', 'e@gmail.com', '01840431225', '2012-07-18', 'Dhaka', 'Ghazipur', 'Kaliakair ', 'Anesthesiology', 'MBBS', '3698521470', 'sdfs');

-- --------------------------------------------------------

--
-- Table structure for table `tempusers`
--

CREATE TABLE `tempusers` (
  `id` int(100) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` int(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tempusers`
--

INSERT INTO `tempusers` (`id`, `userid`, `password`, `status`) VALUES
(20, 'd4', '$2y$10$SJPztjmB8BWinaAnqiXcaeYT1FjrDWBLB7VsZbjc/LdowrxYy7hY2', 2),
(21, 'd5', '$2y$10$sc50J/eIYLqAByf1u2uQmukc7z6bx6y14eW/MwE06Xcvhopt55cMe', 2);

-- --------------------------------------------------------

--
-- Table structure for table `testclinic`
--

CREATE TABLE `testclinic` (
  `id` int(100) NOT NULL,
  `tcname` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `testclinic`
--

INSERT INTO `testclinic` (`id`, `tcname`) VALUES
(1, 'Abir General Hospital'),
(2, 'Ad-Din Hospital'),
(3, 'Al Noor Eye Hospital'),
(4, 'Dhanmondi South East Hospital'),
(5, 'Dr. Salahuddin Hospital');

-- --------------------------------------------------------

--
-- Table structure for table `thana`
--

CREATE TABLE `thana` (
  `id` int(100) NOT NULL,
  `thana` varchar(100) NOT NULL,
  `district_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `thana`
--

INSERT INTO `thana` (`id`, `thana`, `district_id`) VALUES
(1, 'Dhamrai', 'Dhaka'),
(2, 'Kaliakair ', 'Ghazipur'),
(3, 'Hossainpur ', 'Kishoreganj'),
(4, 'Manikganj', 'Manikganj'),
(5, 'Narsingdi Sadar', 'Narsingdi'),
(6, 'Faridpur Sadar', 'Faridpur'),
(7, 'Terakhada', 'Khulna'),
(8, 'Doulatpur ', 'Kushtia'),
(9, 'Magura Sadar', 'Magura'),
(10, 'Jhenaidah Sadar', 'Jhenaidah'),
(11, 'Batiaghatar', 'Bagerhat'),
(12, 'Assasuni', 'Satkhira'),
(21, 'Kotwali ', 'Chittagong'),
(22, 'Patenga', 'Rangamati'),
(23, 'Taltali', 'Barguna '),
(24, 'Kalkini', 'Madaripur'),
(25, 'Durgapur', 'Netrokona'),
(26, 'Sreebardi Upazila', 'Sherpur'),
(27, 'Bholahat Upazila', 'Chapainawabganj'),
(28, 'Atrai Upazila', 'Naogaon'),
(29, 'Rajarhat Upazila', 'Kurigram'),
(30, 'Domar', 'Nilphamari'),
(31, 'Kamalganj', 'Moulvibazar'),
(32, 'Bishwamvarpur', 'Sunamganj');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `userid`, `password`, `status`) VALUES
(32, 'Himi', '$2y$10$8moQr00INAVm/xKXRm0pi.eFbcCnTAXPM13h.mfrNH80t.Bn80vM.', 1),
(53, 'd1', '$2y$10$rlMJcfB0M0mCeT82VGPQT.FtnpIhg//eUMTfdeYBOfdoL/KtKyiQS', 2),
(54, 'd2', '$2y$10$5d/KKQQdVZjTxI0Huqg4SupC9Xg0DoC.La9pNReHQxQJvFNenA6jS', 2),
(55, 'd3', '$2y$10$RGvEipMLoJU1KXZp1w5xB.wGR65WOqMhRTdXUKb69gKUNLVpEqC.m', 2),
(56, 'c1', '$2y$10$RhVwJ1LrA3rumSwK0zV9H.hoCx63ZDLR1gF1O/29P8/Hzl3IWl4B.', 4),
(57, 'c2', '$2y$10$YAlZADrDW0/zm6LHy0MN3.1cQEkJflmSQHN4i9LMqevBcZf50XqbK', 4),
(58, 'c3', '$2y$10$mBYER/WrkQLRzpHtEG9tW./TKEYp2QErXkt..2djZ/97U.B7Rn/fG', 4),
(59, 'c4', '$2y$10$xdE2rIOd9gwDNp4I5lismuHn/15leE5wykj/2iNm9dVia5v0H9bYa', 4),
(60, 'c5', '$2y$10$YdKk6bCrEvNHkEBkX1sCA.JyzSdAGEn51s4d9jej.yqiXgf.f3cq6', 4),
(61, 'p1', '$2y$10$ZjxfVDFvtjpppnQ8kLI28.sAghmKQbHy1OYzcQYxirgggVZ4Z3X06', 3),
(63, 'p2', '$2y$10$X5vrl7NX1rabKBt/9W2cdukMC7u51SS80modMS.Ni8QmjvOd5fqTu', 3),
(64, 'p3', '$2y$10$fqgrd9veJm9C.g5EjNGW1eCs5e0h90bGb22ZtNGvBa/W8bhaHBp6W', 3),
(65, 'p4', '$2y$10$S4m/UY5LqrkOhS2p1aLPXOwAm7yfn7qIl4PdVsxlGX96LHEAXNww.', 3),
(66, 'p5', '$2y$10$tIa6CPxeVppnUwIQICmI4.vU7Q393KZ/T9LqHceLnv7aVmgY2oeRm', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clinics`
--
ALTER TABLE `clinics`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cid` (`cid`);

--
-- Indexes for table `diseases`
--
ALTER TABLE `diseases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `district`
--
ALTER TABLE `district`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `divission`
--
ALTER TABLE `divission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userid` (`userid`);

--
-- Indexes for table `doctorsetschedule`
--
ALTER TABLE `doctorsetschedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patientrecords`
--
ALTER TABLE `patientrecords`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patientrequest`
--
ALTER TABLE `patientrequest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userid` (`userid`);

--
-- Indexes for table `patientwaiting`
--
ALTER TABLE `patientwaiting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slot1`
--
ALTER TABLE `slot1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tempdoctorrequests`
--
ALTER TABLE `tempdoctorrequests`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userid` (`userid`);

--
-- Indexes for table `tempusers`
--
ALTER TABLE `tempusers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userid` (`userid`);

--
-- Indexes for table `testclinic`
--
ALTER TABLE `testclinic`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `thana`
--
ALTER TABLE `thana`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userid` (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clinics`
--
ALTER TABLE `clinics`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `diseases`
--
ALTER TABLE `diseases`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `district`
--
ALTER TABLE `district`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `divission`
--
ALTER TABLE `divission`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `doctorsetschedule`
--
ALTER TABLE `doctorsetschedule`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `patientrecords`
--
ALTER TABLE `patientrecords`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `patientrequest`
--
ALTER TABLE `patientrequest`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `patientwaiting`
--
ALTER TABLE `patientwaiting`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `slot1`
--
ALTER TABLE `slot1`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `tempdoctorrequests`
--
ALTER TABLE `tempdoctorrequests`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tempusers`
--
ALTER TABLE `tempusers`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `testclinic`
--
ALTER TABLE `testclinic`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `thana`
--
ALTER TABLE `thana`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
