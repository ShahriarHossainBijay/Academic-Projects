<?php 
	include '../db/db_connect.php';
	include '../service/clinicservice.php';
	$time="";
	$has_err=false;
	$cid="";

	if (isset($_POST['schedule'])) {
		
		$time=$_POST['time'];
		$cid=$_POST['cid'];
		$date=$_POST['date'];
		if(!$has_err)
		{
			setschedule();
			header ('Location:../views/ClinicSchedule.php');
		}
	}
//insert into clinic schedule table
//data retrieve from slot 1
function slot1($cid)
{
	$csquery="SELECT * FROM slot1 WHERE cid='$cid'";
	$csresult=getdata($csquery);
	return $csresult;
}
//data retrieve from slot 1
//delete clinic schedule
if (isset($_GET['sdeleteid'])) {
	$sid=$_GET['sdeleteid'];
	scheduledelete($sid);
	header ('Location:../views/ClinicSchedule.php');

}
function scheduledelete($id)
{
	$sdelete="DELETE FROM `slot1` WHERE id='$id'";
	execute($sdelete);
}
//delete clinic schedule
//data retrieve from patient records table starts///
function patientrecords($cid)
{
	$records="SELECT * FROM `patientrecords` WHERE cid='$cid'";
	$results=getdata($records);
	return $results;
}
?>