<?php
    header ('Location:../views/HomePage.php');
?>