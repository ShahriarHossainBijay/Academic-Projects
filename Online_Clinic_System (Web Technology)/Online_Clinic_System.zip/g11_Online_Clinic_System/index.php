<?php
    header ('Location:php/HomeControl.php');
?>