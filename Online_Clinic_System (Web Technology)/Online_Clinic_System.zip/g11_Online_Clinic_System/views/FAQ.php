<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>FAQ Page</title>
	<link rel="stylesheet" href="CSS/faq.css">
</head>
<body>
	<div class="footer">
		<div class="contact">
			<label>Contact us</label>
			<br>
			<br>
			<br>
			<span>Call us : 0123456789 , 0174584521</span><br>
			<span>Gmail : example@123.com</span>
			<ul>
				<li><a href="#">Facebook</a></li>
				<li><a href="#">Twitter</a></li>
			</ul>
		</div>
		<div class="faq">
			<label for="">About us</label>
			<br>
			<br>
			<br>
			<span>
				<a href="#">How onlineclinic.com WorksAbout</a> <br>
				onlineclinic.Com
			</span>
		</div>
		<div class="catagory">
			<label>Top Catagory</label>
			<br>
			<br>
			<br>
			<ul>
				<li><a href="#">Children Care</a></li>
				<li><a href="#">Old care</a></li>
				<li><a href="#">Home clean</a></li>
				<li><a href="#">24 hours</a></li>
				<li><a href="#">Per day</a></li>
			</ul>
		</div>
		<div class="location">
			<label>Top Location</label>
			<br>
			<br>
			<br>
			<ul>
				<li>Dhaka</li>
				<li>Khulna</li>
				<li>Rajshahi</li>
				<li>Borisal</li>
				<li>Rangpur</li>
			</ul>
		</div>
	</div>
</body>
</html>